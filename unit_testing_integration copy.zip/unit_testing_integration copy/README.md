# Integration_unit_testing


to run test case - npm run test
to run project - nodemon app.js
